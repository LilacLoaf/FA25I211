<?php

/*
 * Author: Louie Zhu
 * Date: 03/13/2024
 * File: index.php
 * Description: site homepage; redirect users to list_movie.php
 * 
 */

header("Location: list_movie.php");